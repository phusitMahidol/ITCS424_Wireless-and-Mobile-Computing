import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class Exercise {
  final String name;
  final String type;
  final String muscle;
  final String equipment;
  final String difficulty;

  Exercise({
    required this.name,
    required this.type,
    required this.muscle,
    required this.equipment,
    required this.difficulty,
  });

  factory Exercise.fromJson(Map<String, dynamic> json) {
    return Exercise(
      name: json['name'],
      type: json['type'],
      muscle: json['muscle'],
      equipment: json['equipment'],
      difficulty: json['difficulty'],
    );
  }
}

class ExerciseApi {
  static const String apiKey =
      'uROV/0xG5kusne4CgmWRbg==nakxz24dWLVZYJLO'; // Replace with your actual API key
  static const String baseUrl =
      'https://api.api-ninjas.com/v1/exercises?muscle=';

  Future<List<Exercise>> fetchExercises() async {
    final response = await http.get(Uri.parse(baseUrl), headers: {
      'X-Api-Key': apiKey,
    });

    if (response.statusCode == 200) {
      final List<dynamic> jsonData = json.decode(response.body);
      return jsonData.map((json) => Exercise.fromJson(json)).toList();
    } else {
      throw Exception(
          'Failed to load exercises. Status code: ${response.statusCode}');
    }
  }
}

class ExerciseCard extends StatelessWidget {
  final Exercise exercise;

  ExerciseCard({required this.exercise});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0),
      padding: EdgeInsets.all(20.0),
      width: 200.0, // Set the width to your desired value
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF2ADF88), Color(0xFF628F79)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            exercise.name,
            style: TextStyle(
              color: Colors.white,
              fontSize: 16.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 4.0),
          Text(
            'Type: ${exercise.type}',
            style: TextStyle(color: Colors.white, fontSize: 12.0),
          ),
          Text(
            'Muscle: ${exercise.muscle}',
            style: TextStyle(color: Colors.white, fontSize: 12.0),
          ),
          Text(
            'Equipment: ${exercise.equipment}',
            style: TextStyle(color: Colors.white, fontSize: 12.0),
          ),
          Text(
            'Difficulty: ${exercise.difficulty}',
            style: TextStyle(color: Colors.white, fontSize: 12.0),
          ),
        ],
      ),
    );
  }
}

class ApiPage extends StatefulWidget {
  @override
  _ApiPageState createState() => _ApiPageState();
}

class _ApiPageState extends State<ApiPage> {
  late Future<List<Exercise>> futureExercises;

  @override
  void initState() {
    super.initState();
    futureExercises = ExerciseApi().fetchExercises();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF2A2929),
        iconTheme: IconThemeData(color: Colors.white),
        title: Text(
          'Quick Plan',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Container(
        color: Colors.black, // Set the background color to black
        child: Center(
          child: FutureBuilder<List<Exercise>>(
            future: futureExercises,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return CircularProgressIndicator();
              } else if (snapshot.hasError) {
                return Text('Error: ${snapshot.error}');
              } else {
                return Container(
                  width: 350.0, // Set the width to your desired value
                  child: ListView.builder(
                    itemCount: snapshot.data!.length,
                    itemBuilder: (context, index) {
                      return ExerciseCard(exercise: snapshot.data![index]);
                    },
                  ),
                );
              }
            },
          ),
        ),
      ),
    );
  }
}
