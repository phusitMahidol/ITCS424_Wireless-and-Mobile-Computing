import 'package:flutter/material.dart';
import 'select_plan.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LoseWeightPlan',
      home: LoseWeightPlanPage(),
    );
  }
}

class LoseWeightPlanPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SingleChildScrollView(
        child: Container(
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.symmetric(horizontal: 15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: EdgeInsets.only(top: 60.0),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SelectPlanPage()),
                        );
                      },
                      child: Container(
                        width: 90.0,
                        height: 45.0,
                        child: Image.asset('assets/buttonback.png'),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(vertical: 16.0),
                child: Column(
                  children: [
                    Text(
                      "Your's Plan",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 40.0,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 30),
              _buildVerticalBox('assets/LEG_RAISES.jpg', 100.0, 160.0,
                  'LEG RAISES x16', 180.0, 45.0), // Adjust position as needed
              SizedBox(height: 30),
              _buildVerticalBox('assets/BUTT_BRIDGES.jpg', 130.0, 200.0,
                  'BUTT BRIDGES x16', 180.0, 45.0), // Adjust position as needed
              SizedBox(height: 30),
              _buildVerticalBox('assets/PLANK.jpg', 120.0, 250.0,
                  'PLANK  20 SEC', 180.0, 45.0), // Adjust position as needed
              SizedBox(height: 30),
              _buildVerticalBox('assets/BURPEE.jpg', 100.0, 120.0, 'BURPEE x10',
                  180.0, 45.0), // Adjust position as needed
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildVerticalBox(
      String imagePath,
      double imageWidth,
      double imageHeight,
      String text,
      double leftPosition,
      double topPosition) {
    return Container(
      height: 111.0,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Image.asset(
              imagePath,
              width: imageWidth,
              height: imageHeight,
              fit: BoxFit.cover,
            ),
          ),
          Positioned(
            left: leftPosition,
            top: topPosition,
            child: Text(
              text,
              style: TextStyle(
                color: Color(0xFF2ADF88), // Green color
                fontSize: 20.0,
                fontWeight: FontWeight.w600, // Semi-bold
                fontFamily: 'Jost', // Font family
              ),
            ),
          ),
        ],
      ),
    );
  }
}
