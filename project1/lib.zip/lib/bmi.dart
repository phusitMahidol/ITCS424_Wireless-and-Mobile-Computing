import 'package:flutter/material.dart';
import 'lose_weight.dart';

class BMIPage extends StatelessWidget {
  final double weight;
  final double height;

  BMIPage({required this.weight, required this.height});

  @override
  Widget build(BuildContext context) {

    String calculateFormattedBMI(double weight, double height) {
      double bmi = calculateBMI(weight, height);
      return bmi.toStringAsFixed(2);
    }
  
    String formattedBMI = calculateFormattedBMI(weight, height);

    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: EdgeInsets.only(left: 15.0, top: 60.0),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Container(
                    width: 90.0,
                    height: 45.0,
                    child: Image.asset('assets/buttonback.png'),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(vertical: 16.0),
            child: Column(
              children: [
                Text(
                  'Your BMI',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 40.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => LoseWeightPlanPage()),
                    );
                  },
                  child:
                      _buildContainer(formattedBMI.toString()), // Use the calculated BMI
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LoseWeightPlanPage()),
              );
            },
            child: Container(
              width: 345.0,
              height: 52.0,
              margin: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF2ADF88),
                    Color(0xFF628F79),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: _buildNextButton(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNextButton() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.0),
        gradient: LinearGradient(
          colors: [
            Color(0xFF2ADF88),
            Color(0xFF628F79),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Center(
        child: Text(
          'Next',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'Jost',
          ),
        ),
      ),
    );
  }

  Widget _buildContainer(String text) {
    return Container(
      width: 218.0,
      height: 40.0,
      margin: EdgeInsets.only(left: 15.0, bottom: 60),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: Center(
        child: Text(
          text,
          style: TextStyle(
            color: Color(0xFF2ADF88),
            fontSize: 20.0,
            fontWeight: FontWeight.w600,
            fontFamily: 'Jost',
          ),
        ),
      ),
    );
  }

  double calculateBMI(double weight, double height) {
    // BMI formula: weight (kg) / (height (m))^2
    return weight / ((height / 100) * (height / 100));
  }
}
