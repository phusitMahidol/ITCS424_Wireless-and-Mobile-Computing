import 'package:flutter/material.dart';
import 'select_plan.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Home page',
      home: Homepage(),
    );
  }
}

class Homepage extends StatefulWidget {
  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  TextEditingController _usernameController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: EdgeInsets.only(left: 10.0, top: 50.0),
              child: Column(
                children: [
                  Image.asset(
                    'assets/logo.png',
                    width: 400,
                    height: 300,
                  ),
                ],
              ),
            ),
            _buildForm(),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SelectPlanPage()),
                );
              },
              child: _buildNextButton(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildForm() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildTextField("         username", _usernameController),
        _buildTextField("         password", _passwordController, isPassword: true),
        Container(
          margin: EdgeInsets.only(left: 0.0, top: 300.0),
          child: Text(
            'Register',
            style: TextStyle(
              color: Color(0xFF2ADF88),
              fontSize: 20.0,
              fontWeight: FontWeight.bold,
              fontFamily: 'Jost',
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildNextButton() {
    return Container(
      width: 345.0,
      height: 52.0,
      margin: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.0),
        gradient: LinearGradient(
          colors: [
            Color(0xFF2ADF88),
            Color(0xFF628F79),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Center(
        child: Text(
          'Next',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'Jost',
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller, {bool isPassword = false}) {
    return Container(
      width: 218.0,
      height: 40.0,
      margin: EdgeInsets.symmetric(vertical: 9.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: TextField(
        controller: controller,
        obscureText: isPassword,
        style: TextStyle(
          color: Color(0xFF2ADF88),
          fontSize: 20.0,
          fontWeight: FontWeight.w600,
          fontFamily: 'Jost',
        ),
        decoration: InputDecoration(
          contentPadding: EdgeInsets.only(left: 17.0, bottom: 11.0),
          hintText: label,
          hintStyle: TextStyle(
            color: Color(0xFF2ADF88),
            fontSize: 20.0,
            fontWeight: FontWeight.w600,
            fontFamily: 'Jost',
          ),
          border: InputBorder.none,
        ),
      ),
    );
  }
}
